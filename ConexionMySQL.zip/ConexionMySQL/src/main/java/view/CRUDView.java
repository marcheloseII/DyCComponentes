package view;

public interface CRUDView {
    void crear();
    void leer();
    void actualizar();
    void eliminar();
}
