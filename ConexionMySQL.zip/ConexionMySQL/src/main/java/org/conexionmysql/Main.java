package org.conexionmysql;

import controller.*;
import view.*;

import java.sql.Date;


public class Main {
    public static void main(String[] args) {

        MenuView menuView = new MenuView();
        menuView.showMainMenu();

    }
}

